(ns Example
    (:gen-class))

(defn addition [x y]
	(+ x x))