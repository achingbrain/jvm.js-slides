class Example() {

	def addition(a: Int, b: Int): Int = {
		a + b
	}
}